# Match Studio AI — deployment-ready demo

Synthetic football match intelligence demo built with Streamlit.

## Quick start (local)

Use Python **3.12** and run from the repository root:

```bash
python -m venv .venv
# Windows PowerShell: .\.venv\Scripts\Activate.ps1
# macOS/Linux: source .venv/bin/activate
python -m pip install -r requirements.txt
streamlit run match_studio/app.py
```

## Streamlit Community Cloud

1. Create a GitHub repository and upload **the contents of this folder** to its root.
2. Open https://share.streamlit.io and create a new app from that repository.
3. Main file path: `match_studio/app.py`.
4. Choose Python **3.12** if available; deploy.
5. Open the app and check the four phases and interactive replay.

The app loads pre-generated `data_generator/data/*.parquet`, `featured_match/data/*`, `match_studio/output/*.json`, and `match_studio/narratives/*` files. **Do not omit these directories**. No Azure credentials or generation commands are needed for this read-only demo.

## Security

Do not commit `.env`, API keys, tokens, or `.streamlit/secrets.toml`. The original uploaded archive contained `.env`; it has been **excluded** from this package. If that file was ever pushed to a remote repository, rotate the affected credentials and remove the file from Git history.

## Data consistency

The featured-match Parquet files and all four `match_studio/output/` JSON files should be generated from the **same** featured fixture. If you regenerate the fixture, regenerate orchestration outputs and AI narratives locally, then commit the refreshed files together. Do not run regeneration on Streamlit Cloud.

## Troubleshooting

- `ModuleNotFoundError`: check that `requirements.txt` is at the repo root and the correct entrypoint is selected.
- `FileNotFoundError`: verify all generated Parquet/JSON files were committed and paths retain their original directory structure.
- Old data after a push: refresh the app and clear Streamlit caches if needed.
- Private repository: ensure the intended demo viewers have access to the deployed app; test with a separate browser session.
